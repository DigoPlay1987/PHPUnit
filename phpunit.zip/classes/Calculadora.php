<?php 
class Calculadora {
	
	public function soma($n1, $n2) {
		return $n1 + $n2;		
	}
}